Project Introduction
---

1.	测试环境搭建
In order to run the tests, you will need to install
Appium (https://github.com/appium/appium) and Eclipse  (http://www.eclipse.org)
2.	测试工程运行
2.1.	导入工程
To use with Eclipse, go to File then Import and select Existing Maven Projects


2.2.	启动Appium
启动Appium，配置IP地址和端口，启动Server并连接手机（注意：手机需要打开调试端口）。


2.3.	编译并运行工程
2.3.1.	Eclipse图形化运行方式

测试开始后将会在控制台（console）里看到测试日志：

（注：命令行运行方式
To compile and run all tests, run:
    mvn clean test
To run a single test, run:
    mvn -Dtest=com.unicom.apptest.QQMusicTest test）

