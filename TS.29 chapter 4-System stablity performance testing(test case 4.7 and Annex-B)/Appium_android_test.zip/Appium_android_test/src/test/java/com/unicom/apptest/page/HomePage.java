package com.unicom.apptest.page;

import com.unicom.apptest.util.Helpers;

/** Page object for the home page **/
public abstract class HomePage {

    /** Verify the home page has loaded.
     *  Click the accessibility button.
     *  Verify the accessibility page has loaded. **/
    public static void accessibilityClick() {
        loaded();
        Helpers.find("Accessibility").click();
        AccessibilityPage.loaded();
    }

    /** Verify the home page has loaded.
     *  Click the animation button.
     *  Verify the animation page has loaded. **/
    public static void animationClick() {
        loaded();
        Helpers.find("Animation").click();
        AnimationPage.loaded();
    }

    /** Verify the home page has loaded **/
    public static void loaded() {
        Helpers.find("NFC");
    }
}