package com.unicom.apptest.page;

import static com.unicom.apptest.util.Helpers.find;

/** Page object for the accessibility page **/
public abstract class AccessibilityPage {

    /** Verify the accessibility page has loaded **/
    public static void loaded() {
        find("Accessibility Node Provider");
    }
}