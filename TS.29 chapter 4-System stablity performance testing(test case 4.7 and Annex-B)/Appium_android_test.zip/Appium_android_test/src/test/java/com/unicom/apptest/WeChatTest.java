package com.unicom.apptest;

import com.unicom.apptest.util.Helpers;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidKeyCode;
import org.junit.After;
import org.junit.Before;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.net.URL;
import java.nio.file.Paths;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static com.unicom.apptest.util.Helpers.driver;
import static com.unicom.apptest.util.Helpers.for_find;

public class WeChatTest {//extends AppiumTest
    /**
     * Keep the same date prefix to identify job sets.
     **/
    Date date = new Date();
    String sessionId;

    /**
     * Run before each test
     **/
    @Before
    public void setUp() throws Exception {
        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability("appium-version", "1.1.0");
        capabilities.setCapability("platformName", "Android");
        capabilities.setCapability("deviceName", "Android");
//        capabilities.setCapability("platformVersion", "7.0");
        capabilities.setCapability("name", "WeChatTest " + date);
        String userDir = System.getProperty("user.dir");
        URL serverAddress;
        String localApp = "wechat.apk";
        System.out.println("Trying install wechat.apk to phone...");
        {
            String appPath = Paths.get(userDir, localApp).toAbsolutePath().toString();
            capabilities.setCapability("app", appPath);
            serverAddress = new URL("http://127.0.0.1:4723/wd/hub");
            driver = new AndroidDriver(serverAddress, capabilities);
        }
        sessionId = driver.getSessionId().toString();
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        Helpers.init(driver, serverAddress);
    }

    /**
     * Run after each test
     **/
    @After
    public void tearDown() throws Exception {
        if (driver != null) {
            System.out.println(driver.getCapabilities().getCapability("name") + " 测试完成!");
            driver.quit();
        }
    }


    @org.junit.Test
    public void testApp() throws Exception {
//        driver.launchApp();
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        List<WebElement> els = driver.findElementsByClassName("android.widget.Button");
        for (WebElement e : els) {
//            System.out.println("android.widget.Button text:" + e.getText());
            if (e.getText().equals("登录")) {
                e.click();
                System.out.println("click 登录");
                WebElement el = driver.findElementById("com.tencent.mm:id/bun");
                if (el != null) {
                    System.out.println("find phonenumber EditText");
                    el.sendKeys("18600000000");
//                    System.out.println("press back key to exit wechat!");
//                    driver.sendKeyEvent(AndroidKeyCode.BACK);
                } else {
                    System.out.println("find phonenumber EditText failed!");
                }
            }
        }
//        Helpers.wait(for_find("查看支持的机型"));
        driver.removeApp("com.tencent.mm");
    }


//    @org.junit.Test
//    public void ClickButtonApp() throws Exception {
//        Button("Accessibility").click();
//    }


//    @org.junit.Test
//    public void one() throws Exception {
//        text("Accessibility").click();
//        text_exact("Accessibility Node Provider");
//    }
//
//    @org.junit.Test
//    public void two() throws Exception {
//        wait(for_text("Accessibility")).click();
//        wait(for_text_exact("Accessibility Node Provider"));
//    }
//
//    @org.junit.Test
//    public void three() throws Exception {
//        wait(for_text(2)).click();
//        find("Custom Evaluator");
//    }
//
//    @org.junit.Test
//    public void four() throws Exception {
//        setWait(0);
//
//        List<String> cell_names = new ArrayList<String>();
//
//        for (WebElement cell : tags("android.widget.TextView")) {
//            cell_names.add(cell.getAttribute("name"));
//        }
//
//        // delete title cell
//        cell_names.remove(0);
//
//        for (String cell_name : cell_names) {
//            scroll_to_exact(cell_name).click();
//            waitInvisible(for_text_exact(cell_name));
//            back();
//            wait(for_find("Accessibility"));
//            wait(for_find("Animation"));
//        }
//
//        setWait(30); // restore old implicit wait
//    }
}