package com.unicom.apptest.page;

import com.unicom.apptest.util.Helpers;

/** Page object for the animation page **/
public abstract class AnimationPage {

    /** Verify the animation page has loaded **/
    public static void loaded() {
        Helpers.find("Bouncing Balls");
    }
}